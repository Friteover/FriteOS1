#include <linux/fb.h>
#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <unistd.h>

int main() {
    int fbfd = open("/dev/fb0", O_RDWR);
    if (fbfd == -1) {
        perror("Error: cannot open framebuffer device");
        return 1;
    }

    struct fb_var_screeninfo vinfo;
    if (ioctl(fbfd, FBIOGET_VSCREENINFO, &vinfo)) {
        perror("Error reading variable information");
        return 1;
    }

    long int screensize = vinfo.xres * vinfo.yres * vinfo.bits_per_pixel / 8;
    char *fbp = (char *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fbfd, 0);

    printf("FriesOS GUI: Dessin d'une frite jaune sur l'écran (%dx%d)...\n", vinfo.xres, vinfo.yres);

    // Dessiner un fond noir
    for (int y = 0; y < vinfo.yres; y++) {
        for (int x = 0; x < vinfo.xres; x++) {
            long int location = (x + vinfo.xoffset) * (vinfo.bits_per_pixel / 8) +
                               (y + vinfo.yoffset) * (vinfo.xres * (vinfo.bits_per_pixel / 8));
            if (vinfo.bits_per_pixel == 32) {
                *(fbp + location) = 0;     // Blue
                *(fbp + location + 1) = 0; // Green
                *(fbp + location + 2) = 0; // Red
                *(fbp + location + 3) = 0; // Trans
            }
        }
    }

    // Dessiner une frite (un rectangle jaune au milieu)
    int start_x = vinfo.xres / 2 - 20;
    int end_x = vinfo.xres / 2 + 20;
    int start_y = vinfo.yres / 4;
    int end_y = vinfo.yres * 3 / 4;

    for (int y = start_y; y < end_y; y++) {
        for (int x = start_x; x < end_x; x++) {
            long int location = (x + vinfo.xoffset) * (vinfo.bits_per_pixel / 8) +
                               (y + vinfo.yoffset) * (vinfo.xres * (vinfo.bits_per_pixel / 8));
            if (vinfo.bits_per_pixel == 32) {
                *(fbp + location) = 0;       // Blue
                *(fbp + location + 1) = 255; // Green
                *(fbp + location + 2) = 255; // Red (Yellow = R+G)
                *(fbp + location + 3) = 0;
            }
        }
    }

    sleep(5);
    munmap(fbp, screensize);
    close(fbfd);
    return 0;
}
