#!/bin/bash

# ==============================================================================
# FriesOS - Script de build automatique
# Ce script doit être exécuté dans un environnement Linux (Debian/Ubuntu recommandé)
# ==============================================================================

set -e # Arrête le script en cas d'erreur

# Couleurs pour la lisibilité
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Lancement du Build FriesOS 🍟 ===${NC}"

# 1. Dépendances (Vérification)
echo -e "${GREEN}[1/6] Vérification des dépendances...${NC}"
sudo apt-get update
sudo apt-get install -y build-essential libncurses-dev bison flex libssl-dev libelf-dev xorriso grub-pc-bin grub-common wget

# 2. Préparation de l'arborescence
PROJECT_DIR=$(pwd)
BUILD_DIR=$PROJECT_DIR/builds
ROOTFS=$BUILD_DIR/rootfs
mkdir -p $BUILD_DIR $ROOTFS

# 3. Compilation de BusyBox (Le Shell)
echo -e "${GREEN}[2/6] Téléchargement et compilation de BusyBox...${NC}"
if [ ! -d "$BUILD_DIR/busybox-1.36.1" ]; then
    cd $BUILD_DIR
    wget https://busybox.net/downloads/busybox-1.36.1.tar.bz2
    tar -xjf busybox-1.36.1.tar.bz2
fi

cd $BUILD_DIR/busybox-1.36.1
make defconfig
# On force le build statique pour éviter les soucis de lib
sed -i 's/# CONFIG_STATIC is not set/CONFIG_STATIC=y/' .config
make -j$(nproc)
make install CONFIG_PREFIX=$ROOTFS

# 4. Préparation du Kernel Linux
echo -e "${GREEN}[3/6] Téléchargement et compilation du Kernel Linux (Minimal)...${NC}"
KERNEL_VERSION="6.1.55"
if [ ! -d "$BUILD_DIR/linux-$KERNEL_VERSION" ]; then
    cd $BUILD_DIR
    wget https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$KERNEL_VERSION.tar.xz
    tar -xf linux-$KERNEL_VERSION.tar.xz
fi

cd $BUILD_DIR/linux-$KERNEL_VERSION
make x86_64_defconfig
# Optionnel: On pourrait injecter un fichier de config encore plus léger ici
make -j$(nproc) bzImage
cp arch/x86/boot/bzImage $PROJECT_DIR/iso/boot/vmlinuz

# 5. Création de l'Initramfs (Le système de fichiers en RAM)
echo -e "${GREEN}[4/6] Assemblage du RootFS...${NC}"
cd $PROJECT_DIR

# Compilation du petit GUI bonus
gcc -static src/fries_gui.c -o $ROOTFS/bin/fries_gui

# Ajout de nos fichiers personnalisés
mkdir -p $ROOTFS/etc $ROOTFS/proc $ROOTFS/sys $ROOTFS/dev $ROOTFS/tmp
cp src/init $ROOTFS/init
chmod +x $ROOTFS/init
cp src/motd $ROOTFS/etc/motd

# Création de l'archive compressée
cd $ROOTFS
find . -print0 | cpio --null -ov --format=newc | gzip -9 > $PROJECT_DIR/iso/boot/initramfs.cpio.gz

# 6. Génération de l'ISO
echo -e "${GREEN}[5/6] Génération de l'ISO Bootable...${NC}"
cd $PROJECT_DIR
grub-mkrescue -o FriesOS.iso iso/

echo -e "${BLUE}=== Build Terminé ! ===${NC}"
echo -e "Le fichier ${GREEN}FriesOS.iso${NC} est prêt dans $(pwd)"
echo "Pour VirtualBox : Créez une VM Linux 64-bit et montez cette ISO."
